import redis


r = redis.Redis(host="localhost", port=6379)
r.set("name", "daitj")
print(r.get("name"))

